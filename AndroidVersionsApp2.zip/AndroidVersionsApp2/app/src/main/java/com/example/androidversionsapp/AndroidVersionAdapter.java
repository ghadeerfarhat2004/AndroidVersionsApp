package com.example.androidversionsapp;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class AndroidVersionAdapter extends RecyclerView.Adapter<AndroidVersionAdapter.VersionViewHolder> {

    private List<AndroidVersion> versionList;

    // تمرير قائمة البيانات عند إنشاء الـ Adapter
    public AndroidVersionAdapter(List<AndroidVersion> versionList) {
        this.versionList = versionList;
    }

    @NonNull
    @Override
    public VersionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // ربط ملف XML الخاص بالسطر الواحد
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_android_version, parent, false);
        return new VersionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VersionViewHolder holder, int position) {
        AndroidVersion currentVersion = versionList.get(position);

        // وضع البيانات داخل العناصر المرئية للسطر الحالي
        holder.txtCodeName.setText(currentVersion.getCodeName());
        holder.txtVersion.setText("Version: " + currentVersion.getVersion());
        holder.imgLogo.setImageResource(currentVersion.getImageResId());

        // [المهمة 6]: تلوين السطور البديلة لزيادة وضوح القراءة (حسب الموضع زوجي أو فردي)
        if (position % 2 == 0) {
            holder.cardView.setCardBackgroundColor(Color.parseColor("#F5F5F5")); // رمادي فاتح
        } else {
            holder.cardView.setCardBackgroundColor(Color.parseColor("#FFFFFF")); // أبيض
        }

        // [المهمة 5]: إظهار رسالة Toast عند الضغط على العنصر تعرض اسمه وإصداره
        holder.itemView.setOnClickListener(v -> {
            String message = "You selected: " + currentVersion.getCodeName() + " (" + currentVersion.getVersion() + ")";
            Toast.makeText(v.getContext(), message, Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public int getItemCount() {
        return versionList.size();
    }

    // كلاس الـ ViewHolder لربط عناصر الـ XML بمتغيرات الجافا
    static class VersionViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        ImageView imgLogo;
        TextView txtCodeName, txtVersion;

        public VersionViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardView);
            imgLogo = itemView.findViewById(R.id.imgLogo);
            txtCodeName = itemView.findViewById(R.id.txtCodeName);
            txtVersion = itemView.findViewById(R.id.txtVersion);
        }
    }
}