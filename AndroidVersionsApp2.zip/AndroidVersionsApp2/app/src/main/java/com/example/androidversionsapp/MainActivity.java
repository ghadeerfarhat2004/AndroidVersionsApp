package com.example.androidversionsapp;

import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AndroidVersionAdapter adapter;
    private List<AndroidVersion> versionList;
    private boolean isSorted = false; // تتبع حالة الترتيب الحالي للقائمة

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        Button btnSort = findViewById(R.id.btnSort);

        // [المهمة 1]: تنظيم عناصر الـ RecyclerView بشكل عمودي سلس
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // [المهمة 4]: تعبئة القائمة بالبيانات المحددة في جدول الواجب الرسمي
        versionList = new ArrayList<>();

        // تم ربط العناصر بأسماء الصور الفعلية الموجودة في مجلد drawable لديكِ لحل خطأ الأحمر تماماً
        versionList.add(new AndroidVersion(R.drawable.oreo1, "Donut", "1.6"));
        versionList.add(new AndroidVersion(R.drawable.oreo2, "Éclair", "2.0-2.1"));
        versionList.add(new AndroidVersion(R.drawable.oreo3, "Froyo", "2.2-2.2.3"));
        versionList.add(new AndroidVersion(R.drawable.oreo4, "Gingerbread", "2.3-2.3.7"));
        versionList.add(new AndroidVersion(R.drawable.oreo5, "Honeycomb", "3.0-3.2.6"));
        versionList.add(new AndroidVersion(R.drawable.oreo1, "Ice Cream Sandwich", "4.0-4.0.4"));
        versionList.add(new AndroidVersion(R.drawable.oreo2, "Jelly Bean", "4.1-4.3.1"));
        versionList.add(new AndroidVersion(R.drawable.oreo3, "KitKat", "4.4-4.4.4"));
        versionList.add(new AndroidVersion(R.drawable.oreo4, "Lollipop", "5.0-5.1.1"));
        versionList.add(new AndroidVersion(R.drawable.oreo5, "Marshmallow", "6.0-6.0.1"));
        versionList.add(new AndroidVersion(R.drawable.oreo1, "Nougat", "7.0-7.1.2"));
        versionList.add(new AndroidVersion(R.drawable.oreo2, "Oreo", "8.0-8.1"));

        // ربط المحوّل (Adapter) بالـ RecyclerView لعرض البيانات على الشاشة
        adapter = new AndroidVersionAdapter(versionList);
        recyclerView.setAdapter(adapter);

        // [المهمة المتقدمة 7]: زر الترتيب الأبجدي حسب اسم الكود
        btnSort.setOnClickListener(v -> {
            if (!isSorted) {
                // ترتيب تصاعدي من الـ A إلى Z
                Collections.sort(versionList, (v1, v2) -> v1.getCodeName().compareToIgnoreCase(v2.getCodeName()));
                isSorted = true;
                btnSort.setText("إلغاء الترتيب");
            } else {
                // إعادة القائمة للترتيب العكسي أو الأصلي عند الضغط مجدداً
                Collections.reverse(versionList);
                isSorted = false;
                btnSort.setText("ترتيب القائمة أبجدياً");
            }
            // إعلام الـ RecyclerView بحدوث تغيير لتحديث واجهة المستخدم فوراً
            adapter.notifyDataSetChanged();
        });
    }
}