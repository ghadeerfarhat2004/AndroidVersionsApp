package com.example.androidversionsapp;

public class AndroidVersion {
    private int imageResId; // لتخزين معرف الصورة المضافة في drawable
    private String codeName; // اسم الإصدار (مثال: Donut)
    private String version;  // رقم الإصدار (مثال: 1.6)

    // Constructor (المشيد لإنشاء الكائن وتعبئته)
    public AndroidVersion(int imageResId, String codeName, String version) {
        this.imageResId = imageResId;
        this.codeName = codeName;
        this.version = version;
    }

    // دالات جلب البيانات (Getters) لكي نتمكن من قراءتها لاحقاً في الـ Adapter
    public int getImageResId() { return imageResId; }
    public String getCodeName() { return codeName; }
    public String getVersion() { return version; }
}